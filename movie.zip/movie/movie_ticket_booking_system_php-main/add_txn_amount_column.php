<?php
include 'connection.php';

// Add TXN_AMOUNT column if it doesn't exist
$sql = "ALTER TABLE bookingtable ADD COLUMN IF NOT EXISTS TXN_AMOUNT DECIMAL(10,2) DEFAULT 0";

if (mysqli_query($con, $sql)) {
    echo "TXN_AMOUNT column added successfully";
} else {
    echo "Error adding TXN_AMOUNT column: " . mysqli_error($con);
}
?>
