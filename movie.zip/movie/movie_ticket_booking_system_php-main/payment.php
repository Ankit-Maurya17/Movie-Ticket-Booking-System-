<?php
require_once 'lib/config_paytm.php';
require_once 'lib/encdec_paytm.php';

session_start();

// Get order details from session
$order_id = $_SESSION['ORDERID'];
$amount = $_SESSION['amount'];
$customer_id = $_SESSION['customer_id'];
$customer_email = $_SESSION['customer_email'];
$customer_phone = $_SESSION['customer_phone'];

// Parameters for Paytm
$paramList = array();
$paramList["MID"] = PAYTM_MERCHANT_MID;
$paramList["ORDER_ID"] = $order_id;
$paramList["CUST_ID"] = $customer_id;
$paramList["INDUSTRY_TYPE_ID"] = "Retail";
$paramList["CHANNEL_ID"] = "WEB";
$paramList["TXN_AMOUNT"] = $amount;
$paramList["WEBSITE"] = PAYTM_MERCHANT_WEBSITE;
$paramList["CALLBACK_URL"] = "http://localhost/movie/movie_ticket_booking_system_php-main/response.php";

// Generate checksum
$checksum = getChecksumFromArray($paramList, PAYTM_MERCHANT_KEY);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment - Movie Ticket Booking</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h4 class="text-center">Payment Details</h4>
                    </div>
                    <div class="card-body">
                        <form method="post" action="<?php echo PAYTM_TXN_URL ?>" name="paytm">
                            <?php
                            foreach($paramList as $name => $value) {
                                echo '<input type="hidden" name="' . $name . '" value="' . $value . '">' . "\n";
                            }
                            ?>
                            <input type="hidden" name="CHECKSUMHASH" value="<?php echo $checksum; ?>">
                            
                            <div class="form-group">
                                <label>Order ID:</label>
                                <p><?php echo $order_id; ?></p>
                            </div>
                            
                            <div class="form-group">
                                <label>Amount:</label>
                                <p>₹<?php echo $amount; ?></p>
                            </div>
                            
                            <div class="form-group">
                                <button type="submit" class="btn btn-primary btn-block">Proceed to Payment</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</body>
</html>
