<?php
session_start();
$error = isset($_GET['error']) ? urldecode($_GET['error']) : 'Payment failed. Please try again.';
$status = isset($_GET['status']) ? $_GET['status'] : 'failure';
$message = isset($_GET['message']) ? urldecode($_GET['message']) : 'Payment failed';

include 'connection.php';

// Get the latest failed booking
$query = "SELECT * FROM bookingtable WHERE payment_status = 'Failed' ORDER BY bookingDate DESC LIMIT 1";
$result = mysqli_query($con, $query);
$booking = mysqli_fetch_assoc($result);

if (!$booking) {
    header('Location: index.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Failed - Movie Ticket Booking</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header bg-danger text-white">
                        <h4 class="text-center">Payment Failed</h4>
                    </div>
                    <div class="card-body">
                        <div class="text-center mb-4">
                            <i class="fa fa-times-circle fa-5x text-danger"></i>
                            <h5 class="mt-3">We're sorry, your payment was not successful.</h5>
                        </div>

                        <div class="alert alert-danger" role="alert">
                            <strong>Error:</strong> <?php echo htmlspecialchars($error); ?>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Order ID:</label>
                                    <p class="form-control-plaintext"><?php echo isset($booking['ORDERID']) ? $booking['ORDERID'] : 'N/A'; ?></p>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Amount:</label>
                                    <p class="form-control-plaintext">₹<?php echo isset($booking['TXN_AMOUNT']) ? $booking['TXN_AMOUNT'] : 'N/A'; ?></p>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <label>Movie:</label>
                            <p class="form-control-plaintext"><?php echo isset($booking['movieTitle']) ? $booking['movieTitle'] : 'N/A'; ?></p>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Theatre:</label>
                                    <p class="form-control-plaintext"><?php echo isset($booking['bookingTheatre']) ? $booking['bookingTheatre'] : 'N/A'; ?></p>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Show Time:</label>
                                    <p class="form-control-plaintext"><?php 
                                        $date = isset($booking['bookingDate']) ? $booking['bookingDate'] : 'N/A';
                                        $time = isset($booking['bookingTime']) ? $booking['bookingTime'] : 'N/A';
                                        echo $date . ' ' . $time;
                                    ?></p>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <label>Booking Details:</label>
                            <p class="form-control-plaintext">Name: <?php 
                                $fname = isset($booking['bookingFName']) ? $booking['bookingFName'] : '';
                                $lname = isset($booking['bookingLName']) ? $booking['bookingLName'] : '';
                                echo $fname . ' ' . $lname;
                            ?></p>
                            <p class="form-control-plaintext">Phone: <?php echo isset($booking['bookingPNumber']) ? $booking['bookingPNumber'] : 'N/A'; ?></p>
                            <p class="form-control-plaintext">Email: <?php echo isset($booking['bookingEmail']) ? $booking['bookingEmail'] : 'N/A'; ?></p>
                        </div>

                        <div class="text-center mt-4">
                            <a href="index.php" class="btn btn-primary">Back to Home</a>
                            <a href="booking.php?id=<?php echo isset($booking['movieID']) ? $booking['movieID'] : ''; ?>" class="btn btn-secondary">Try Again</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</body>
</html>
