<?php
header("Pragma: no-cache");
header("Cache-Control: no-cache");
header("Expires: 0");

require_once "./lib/config_paytm.php";
require_once "./lib/encdec_paytm.php";

session_start();

// Check if required session variables exist
if (!isset($_SESSION['ORDERID']) || !isset($_SESSION['customer_id']) || !isset($_SESSION['amount'])) {
    header('Location: index.php');
    exit;
}

$checkSum = "";
$paramList = array();

// Get payment details from session
$ORDER_ID = $_SESSION['ORDERID'];
$CUST_ID = $_SESSION['customer_id'];
$TXN_AMOUNT = $_SESSION['amount'];
$EMAIL = $_SESSION['customer_email'] ?? '';
$MOBILE = $_SESSION['customer_phone'] ?? '';

// Create an array having all required parameters for creating checksum.
$paramList["MID"] = PAYTM_MERCHANT_MID;
$paramList["ORDER_ID"] = $ORDER_ID;
$paramList["CUST_ID"] = $CUST_ID;
$paramList["INDUSTRY_TYPE_ID"] = "Retail";
$paramList["CHANNEL_ID"] = "WEB";
$paramList["TXN_AMOUNT"] = $TXN_AMOUNT;
$paramList["WEBSITE"] = PAYTM_MERCHANT_WEBSITE;
$paramList["CALLBACK_URL"] = "http://localhost/movie/movie_ticket_booking_system_php-main/response.php";

// Optional parameters
$paramList["EMAIL"] = $EMAIL;
$paramList["MOBILE_NO"] = $MOBILE;
$paramList["TXN_DATE"] = date('Y-m-d H:i:s');

// Enable all payment modes
$paramList["PAYMENT_MODE_ONLY"] = "NO"; // Allow all payment modes
$paramList["PAYMENT_TYPE_ID"] = "ALL";  // All payment types

//Here checksum string will return by getChecksumFromArray() function.
$checkSum = getChecksumFromArray($paramList, PAYTM_MERCHANT_KEY);

// Add checksum to the parameter list
$paramList["CHECKSUMHASH"] = $checkSum;

try {
    // Check if checksum is generated
    if (empty($checkSum)) {
        throw new Exception('Checksum is empty');
    }
} catch (Exception $e) {
    // Log the error and redirect to error page
    error_log($e->getMessage());
    header('Location: error.php');
    exit;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Processing - Movie Ticket Booking</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h4 class="mb-0">Payment Processing</h4>
                    </div>
                    <div class="card-body">
                        <form method="post" action="<?php echo PAYTM_TXN_URL ?>" name="paytm">
                            <?php
                            foreach($paramList as $name => $value) {
                                echo '<input type="hidden" name="' . $name . '" value="' . $value . '">' . "\n";
                            }
                            ?>
                            
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Order ID:</label>
                                        <p class="form-control-plaintext"><?php echo $ORDER_ID; ?></p>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Amount:</label>
                                        <p class="form-control-plaintext">₹<?php echo $TXN_AMOUNT; ?></p>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Email:</label>
                                        <p class="form-control-plaintext"><?php echo $EMAIL; ?></p>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Phone:</label>
                                        <p class="form-control-plaintext"><?php echo $MOBILE; ?></p>
                                    </div>
                                </div>
                            </div>

                            <div class="text-center mt-4">
                                <h5>Available Payment Options:</h5>
                                <div class="payment-options mt-3">
                                    <i class="fa fa-credit-card" style="font-size:24px; margin-right:10px;"></i>
                                    <i class="fa fa-bank" style="font-size:24px; margin-right:10px;"></i>
                                    <i class="fa fa-rupee" style="font-size:24px; margin-right:10px;"></i>
                                    <i class="fa fa-mobile" style="font-size:24px; margin-right:10px;"></i>
                                </div>
                            </div>

                            <div class="form-group mt-4">
                                <button type="submit" class="btn btn-success btn-lg btn-block">
                                    <i class="fa fa-credit-card"></i> Proceed to Payment
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</body>
</html>