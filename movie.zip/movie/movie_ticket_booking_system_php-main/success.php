<?php
session_start();

include 'connection.php';

// Get order ID from URL
$order_id = isset($_GET['order_id']) ? $_GET['order_id'] : '';

if (empty($order_id)) {
    header('Location: index.php');
    exit();
}

// Get booking details
$query = "SELECT * FROM bookingtable WHERE ORDERID = '$order_id'";
$result = mysqli_query($con, $query);
$booking = mysqli_fetch_assoc($result);

if (!$booking) {
    header('Location: index.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Successful - Movie Ticket Booking</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header bg-success text-white">
                        <h4 class="mb-0">Payment Successful</h4>
                    </div>
                    <div class="card-body">
                        <div class="text-center mb-4">
                            <i class="fa fa-check-circle fa-5x text-success"></i>
                            <h5 class="mt-3">Thank you for your payment!</h5>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Order ID:</label>
                                    <p class="form-control-plaintext"><?php echo $booking['ORDERID']; ?></p>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Amount:</label>
                                    <p class="form-control-plaintext">₹<?php echo $booking['TXN_AMOUNT']; ?></p>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <label>Movie:</label>
                            <p class="form-control-plaintext"><?php echo $booking['movieTitle']; ?></p>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Theatre:</label>
                                    <p class="form-control-plaintext"><?php echo $booking['bookingTheatre']; ?></p>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Show Time:</label>
                                    <p class="form-control-plaintext"><?php echo $booking['bookingDate'] . ' ' . $booking['bookingTime']; ?></p>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <label>Booking Details:</label>
                            <p class="form-control-plaintext">Name: <?php echo $booking['bookingFName'] . ' ' . $booking['bookingLName']; ?></p>
                            <p class="form-control-plaintext">Phone: <?php echo $booking['bookingPNumber']; ?></p>
                            <p class="form-control-plaintext">Email: <?php echo $booking['bookingEmail']; ?></p>
                        </div>

                        <div class="text-center mt-4">
                            <a href="index.php" class="btn btn-primary">Back to Home</a>
                            <a href="booking.php?id=<?php echo $booking['movieID']; ?>" class="btn btn-secondary">Book Another Ticket</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</body>
</html>
