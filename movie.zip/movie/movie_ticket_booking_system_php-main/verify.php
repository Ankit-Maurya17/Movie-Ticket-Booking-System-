<?php
include "connection.php";
session_start();

// Check if form was submitted
if (!isset($_POST['submit'])) {
    echo "<script>alert('You are not supposed to come here directly');window.location.href='index.php';</script>";
    exit;
}

// Get form data
$fname = $_POST['fName'];
$lname = $_POST['lName'];
$email = $_POST['email'];
$mobile = $_POST['pNumber'];
$theatre = $_POST['theatre'];
$type = $_POST['type'];
$date = $_POST['date'];
$time = $_POST['hour'];
$movieid = $_POST['movie_id'];

// Generate unique IDs
$order = "ARVR" . rand(10000, 99999999);
$cust = "CUST" . rand(1000, 999999);

// Store payment details in session
$_SESSION['ORDERID'] = $order;
$_SESSION['customer_id'] = $cust;
$_SESSION['customer_email'] = $email;
$_SESSION['customer_phone'] = $mobile;

// Set amount based on theatre type
switch ($theatre) {
    case "main-hall":
        $amount = 200;
        break;
    case "vip-hall":
        $amount = 500;
        break;
    case "private-hall":
        $amount = 900;
        break;
    default:
        $amount = 200;
}

// Store amount in session
$_SESSION['amount'] = $amount;

// Insert booking into database
$qry = "INSERT INTO bookingtable(
    movieID,
    bookingTheatre,
    bookingType,
    bookingDate,
    bookingTime,
    bookingFName,
    bookingLName,
    bookingPNumber,
    bookingEmail,
    amount,
    ORDERID,
    TXN_AMOUNT
) VALUES (
    '$movieid',
    '$theatre',
    '$type',
    '$date',
    '$time',
    '$fname',
    '$lname',
    '$mobile',
    '$email',
    'Not Paid',
    '$order',
    '$amount'
)";

$result = mysqli_query($con, $qry);

if ($result) {
    // Redirect to payment page
    header('Location: pgRedirect.php');
    exit;
} else {
    // Log the error for debugging
    error_log("Database error: " . mysqli_error($con));
    error_log("Query: " . $qry);
    
    echo "<script>
        alert('Error booking ticket. Please try again or contact support.');
        window.location.href='index.php';
    </script>";
    exit;
}
?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <title>Payment Details</title>
</head>

<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h4 class="text-center">Payment Details</h4>
                    </div>
                    <div class="card-body">
                        <form method="post" action="pgRedirect.php">
                            <div class="form-group">
                                <label>Order ID:</label>
                                <p><?php echo $order; ?></p>
                                <input type="hidden" name="ORDER_ID" value="<?php echo $order; ?>">
                            </div>

                            <div class="form-group">
                                <label>Name:</label>
                                <p><?php echo $_POST['fName'] . " " . $_POST['lName']; ?></p>
                            </div>

                            <div class="form-group">
                                <label>Theatre:</label>
                                <p><?php echo $_POST['theatre']; ?></p>
                            </div>

                            <div class="form-group">
                                <label>Type:</label>
                                <p><?php echo $_POST['type']; ?></p>
                            </div>

                            <div class="form-group">
                                <label>Amount:</label>
                                <p>₹<?php echo $_SESSION['amount']; ?></p>
                                <input type="hidden" name="TXN_AMOUNT" value="<?php echo $_SESSION['amount']; ?>">
                                <input type="hidden" name="CUST_ID" value="<?php echo $cust; ?>">
                                <input type="hidden" name="INDUSTRY_TYPE_ID" value="Retail">
                                <input type="hidden" name="CHANNEL_ID" value="WEB">
                            </div>

                            <div class="form-group">
                                <button type="submit" class="btn btn-primary btn-block">Proceed to Payment</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</body>

</html>