<?php
require_once './lib/config_paytm.php';
require_once './lib/encdec_paytm.php';

session_start();

$paytmChecksum = "";
$paramList = array();
$isValidChecksum = "FALSE";

$paramList = $_POST;
$paytmChecksum = isset($_POST["CHECKSUMHASH"]) ? $_POST["CHECKSUMHASH"] : ""; //Sent by Paytm pg

// Verify all parameters received from Paytm pg to your application
$isValidChecksum = verifychecksum_e($paramList, PAYTM_MERCHANT_KEY, $paytmChecksum); //will return TRUE or FALSE string

try {
    if($isValidChecksum == "TRUE") {
        if ($_POST["STATUS"] == "TXN_SUCCESS") {
            // Update the booking status to paid
            include 'connection.php';
            $order_id = $_POST['ORDERID'];
            
            // Update booking status
            $update_query = "UPDATE bookingtable SET amount = 'Paid', payment_status = 'Success', TXN_AMOUNT = '$_POST[TXN_AMOUNT]' WHERE ORDERID = '$order_id'";
            mysqli_query($con, $update_query);

            // Try to log payment success
            try {
                $log_query = "INSERT INTO payment_logs (order_id, amount, status, response) VALUES ('$order_id', '$_POST[TXN_AMOUNT]', 'Success', '" . mysqli_real_escape_string($con, json_encode($_POST)) . "')";
                mysqli_query($con, $log_query);
            } catch (Exception $e) {
                error_log("Failed to log payment success: " . $e->getMessage());
            }

            // Redirect to success page
            header('Location: success.php?order_id=' . $order_id . '&status=success&message=Payment+successful');
            exit();
        } else {
            // Get the error message from Paytm
            $error_msg = isset($_POST['RESPMSG']) ? $_POST['RESPMSG'] : 'Payment failed';
            
            // Try to log payment failure
            include 'connection.php';
            $order_id = $_POST['ORDERID'];
            try {
                $log_query = "INSERT INTO payment_logs (order_id, amount, status, response) VALUES ('$order_id', '$_POST[TXN_AMOUNT]', 'Failed', '" . mysqli_real_escape_string($con, json_encode($_POST)) . "')";
                mysqli_query($con, $log_query);
            } catch (Exception $e) {
                error_log("Failed to log payment failure: " . $e->getMessage());
            }

            // Update booking status
            $update_query = "UPDATE bookingtable SET payment_status = 'Failed', TXN_AMOUNT = '$_POST[TXN_AMOUNT]' WHERE ORDERID = '$order_id'";
            mysqli_query($con, $update_query);

            // Redirect to failure page with error details
            header('Location: failure.php?error=' . urlencode($error_msg) . '&status=failure&message=Payment+failed');
            exit();
        }
    } else {
        // Handle invalid checksum
        include 'connection.php';
        $order_id = isset($_POST['ORDERID']) ? $_POST['ORDERID'] : 'N/A';
        try {
            $log_query = "INSERT INTO payment_logs (order_id, amount, status, response) VALUES ('$order_id', '0', 'InvalidChecksum', '" . mysqli_real_escape_string($con, json_encode($_POST)) . "')";
            mysqli_query($con, $log_query);
        } catch (Exception $e) {
            error_log("Failed to log invalid checksum: " . $e->getMessage());
        }

        // Redirect to failure page with error details
        header('Location: failure.php?error=' . urlencode('Invalid checksum received from Paytm') . '&status=error&message=Invalid+checksum');
        exit();
    }
} catch (Exception $e) {
    // Log any unexpected errors
    error_log("Payment processing error: " . $e->getMessage());
    
    // Redirect to failure page
    header('Location: failure.php?error=' . urlencode('An unexpected error occurred during payment processing') . '&status=error&message=Unexpected+error');
    exit();
}
?>
