<?php
include 'connection.php';

// Add payment_status column if it doesn't exist
$sql = "ALTER TABLE bookingtable ADD COLUMN IF NOT EXISTS payment_status VARCHAR(20) DEFAULT 'Pending'";

if (mysqli_query($con, $sql)) {
    echo "Payment status column added successfully";
} else {
    echo "Error adding payment status column: " . mysqli_error($con);
}
?>
